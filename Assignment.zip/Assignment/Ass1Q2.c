#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"
#include "stdio.h"

typedef struct {
    uint8_t dataID;
    int32_t DataValue;
} Data_t;

QueueHandle_t Queue1;
TaskHandle_t TaskHandle_1;
TaskHandle_t TaskHandle_2;

volatile uint8_t G_DataID = 0;
volatile int32_t G_DataValue = 0;

void ExampleTask1(void *pV);
void ExampleTask2(void *pV);

int main(void) {
    // Create the queue
    Queue1 = xQueueCreate(5, sizeof(Data_t));
    if (Queue1 == NULL) {
        // Queue creation failed
        printf("Failed to create queue.\n");
        while (1);
    }

    // Create the tasks
    xTaskCreate(ExampleTask1, "Task1", 1000, NULL, 1, &TaskHandle_1);
    xTaskCreate(ExampleTask2, "Task2", 1000, NULL, 1, &TaskHandle_2);

    // Start the scheduler
    vTaskStartScheduler();

    // Should never reach here
    while (1);
}

void ExampleTask1(void *pV) {
    Data_t dataToSend;

    while (1) {
        // Populate the data structure
        dataToSend.dataID = G_DataID;
        dataToSend.DataValue = G_DataValue;

        // Send data to the queue
        if (xQueueSend(Queue1, &dataToSend, portMAX_DELAY) != pdPASS) {
            printf("Failed to send to queue.\n");
        }

        // Delay for 500ms
        vTaskDelay(pdMS_TO_TICKS(500));
    }
}

void ExampleTask2(void *pV) {
    Data_t receivedData;
    UBaseType_t originalPriority = uxTaskPriorityGet(NULL);

    while (1) {
        // Receive data from the queue
        if (xQueueReceive(Queue1, &receivedData, portMAX_DELAY) == pdPASS) {
            printf("Received dataID: %d, DataValue: %d\n", receivedData.dataID, receivedData.DataValue);

            // Process the data based on the given conditions
            switch (receivedData.dataID) {
                case 0:
                    vTaskDelete(NULL);
                    break;
                case 1:
                    if (receivedData.DataValue == 0) {
                        vTaskPrioritySet(NULL, originalPriority + 2);
                    } else if (receivedData.DataValue == 1) {
                        vTaskPrioritySet(NULL, originalPriority);
                    } else if (receivedData.DataValue == 2) {
                        vTaskDelete(NULL);
                    }
                    break;
                default:
                    // Handle unexpected dataID values
                    break;
            }
        }
    }
}

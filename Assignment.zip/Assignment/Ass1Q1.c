#include <stdint.h>
#include <stdio.h>


volatile uint8_t g_ReadDIpinSts = 0;
volatile uint8_t g_AppDIpinSts = 0;

static uint8_t stableCounter[8] = {0};

int ISR_DIsampling();

int main() {
    for (int i = 0; i < 50; i++) {
        g_ReadDIpinSts = (i % 2 == 0) ? 0xFF : 0x00;
        ISR_DIsampling();
        printf("ISR Call %d: g_AppDIpinSts = 0x%02X\n", i, g_AppDIpinSts);
    }
    return 0;
}
int ISR_DIsampling(){
    static uint8_t prevReadDIpinSts = 0xFF;
    for (int i = 0; i < 8; i++) {
        uint8_t mask = 1 << i;
        if ((g_ReadDIpinSts & mask) == (prevReadDIpinSts & mask)) {
            stableCounter[i]++;
        } else {
            stableCounter[i] = 0;
        }
        if (stableCounter[i] >= 10) {
            if (g_ReadDIpinSts & mask) {
                g_AppDIpinSts |= mask;
            } else {
                g_AppDIpinSts &= ~mask;
        }
    }
    prevReadDIpinSts = g_ReadDIpinSts;
    return 0;
 }
}
